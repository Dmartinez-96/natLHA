#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  8 14:35:38 2023

Main parent routine to call other routines.

@author: Dakotah Martinez
"""

from terminal_UI import main

if __name__ == "__main__":
    main()
