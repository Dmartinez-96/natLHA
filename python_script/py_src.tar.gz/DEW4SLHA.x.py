# -*- coding: utf-8 -*-
"""
Created on Thu Jun  8 17:58:33 2023

@author: dakot
"""

import os

if __name__ == '__main__':
    os.chdir(".{0}src".format(os.sep))
    os.system('python DEW4SLHA.x.py')
