A sample point with a SLHA file is included for the CMSSM, NUHM1, NUHM2, NUHM3, NUHM4, and the pMSSM30 for users to test. 
Individual sample DEW4SLHA solution lists are included for each of these models, one for each of $\Delta_{BG,EW,HS}$.
# DO NOT CHANGE THE VALUES IN THESE FILES, AS THEY ARE CALCULATED QUANTITIES FROM SOFTSUSY & DEW4SLHA.
Generate your own file if you wish to test a different BM point in any of these models.
